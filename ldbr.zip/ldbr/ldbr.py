import os
import requests
import sys
from colorama import Fore
from urllib.parse import urlparse
import __sdk

try:
    website = sys.argv[1]
    wordlist = sys.argv[2]
except:
    print('Voce nao passou os parametros necessarios ex: pinto.py (website) (wordlist)')

def clear_sc():
    try:
        os.system('clear')
        print(__sdk.banner)
    except:
        os.system('cls')
        print(__sdk.banner)

def clear():
    try:
        os.system('clear')
    except:
        os.system('cls')

def dirb(website, wordlist):
    clear_sc()
    parsed_url = urlparse(website)
    print(__sdk.barra + parsed_url.netloc)
    print(__sdk.barra_b)
    base = f'https://{parsed_url.netloc}/'
    with open(wordlist, 'r') as wl:
        for line in wl:
            directory = line.strip()
            url = base + directory
            response = requests.get(url)
            if response.status_code == 200:
                print(Fore.GREEN + f'directory found: {url} code [200]')
            elif response.status_code == 404:
                print(Fore.RED + f'directory not found: {url} code [404]')
            else:
                print(Fore.YELLOW + f"Unexpected status code {response.status_code} for {url}")

if __name__ == '__main__':
    try:
        dirb(website,wordlist)
    except Exception as e:
        print(e)
    except KeyboardInterrupt:
        clear()
        exit()
